"""
Central logging setup + robust stream-to-log utilities.

Goals:
- Colorful console logs via stdlib logging (no 3rd party deps).
- Pretty-printed JSON when input lines contain JSON (single or multi-line).
- Detect severity from `message_type` field or from text like "| ERROR |".
- Special handling for NeuroSan's multi-line 'Request reporting: {...}' messages.
- Keep parsing code here; run.py stays minimal.
"""

from __future__ import annotations

import io
import json
import logging
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from logging.handlers import TimedRotatingFileHandler


# ---------- ANSI COLORS ----------

class Colors:
    RESET = "\033[0m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    CYAN = "\033[36m"
    RED = "\033[31m"
    BOLD_RED = "\033[1;31m"
    BLUE = "\033[34m"


class ColoredFormatter(logging.Formatter):
    """Colorize level, timestamp, and location for console output."""

    LEVEL_COLORS = {
        "DEBUG": Colors.BLUE,
        "INFO": Colors.GREEN,
        "WARNING": Colors.YELLOW,
        "ERROR": Colors.RED,
        "CRITICAL": Colors.BOLD_RED,
    }

    def __init__(self, fmt: str, datefmt: str, use_colors: bool = True) -> None:
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.use_colors = use_colors

    def format(self, record: logging.LogRecord) -> str:
        if not self.use_colors:
            return super().format(record)

        original_level = record.levelname
        level_color = self.LEVEL_COLORS.get(original_level, "")
        record.levelname = f"{level_color}{original_level:<8}{Colors.RESET}"

        # Colorize timestamp and location
        record.asctime = f"{Colors.GREEN}{self.formatTime(record, self.datefmt)}{Colors.RESET}"
        location = f"{record.name}:{record.funcName}:{record.lineno}"
        record.location = f"{Colors.CYAN}{location}{Colors.RESET}"

        try:
            return super().format(record)
        finally:
            record.levelname = original_level


# ---------- PUBLIC API ----------

_logging_initialized = False

# Default message_type → logging level
MESSAGE_TYPE_TO_LEVEL: Dict[str, int] = {
    "trace": logging.DEBUG,
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "other": logging.INFO,
    "success": logging.INFO,
    "warning": logging.WARNING,
    "warn": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
    "fatal": logging.CRITICAL,
}

# Regex to detect simple level words in plain text (e.g., uvicorn/fastapi lines)
_LEVEL_WORD = re.compile(r"\b(DEBUG|INFO|WARNING|ERROR|CRITICAL|FATAL)\b", re.IGNORECASE)


def _load_optional_json_config() -> Dict[str, Any]:
    """Load logging.json if present (non-fatal)."""
    try:
        with open("logging.json", "r", encoding="utf-8") as f:
            cfg = json.load(f)
            return cfg if isinstance(cfg, dict) else {}
    except Exception:
        return {}


def setup_logging(
    log_level: str = "INFO",
    enable_file_logging: bool = True,
    force: bool = False,
    file_path: Optional[str] = None,
) -> None:
    """
    Initialize logging once; can be re-run with force=True to update level/handlers.
    """
    global _logging_initialized, MESSAGE_TYPE_TO_LEVEL

    if _logging_initialized and not force:
        return

    cfg = _load_optional_json_config()
    # Allow message_type mapping override via logging.json
    mt_map = cfg.get("message_type_to_level")
    if isinstance(mt_map, dict):
        for k, v in mt_map.items():
            if isinstance(k, str) and isinstance(v, str):
                up = v.upper()
                if hasattr(logging, up):
                    MESSAGE_TYPE_TO_LEVEL[k.lower()] = getattr(logging, up)

    # Root logger
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()

    # Console handler (color)
    console = logging.StreamHandler(sys.stderr)
    # Respect requested log level for console
    console.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    console.setFormatter(
        ColoredFormatter(
            fmt="%(asctime)s | %(levelname)s | %(location)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            use_colors=True,
        )
    )
    root.addHandler(console)

    # Optional: rotating file handler (plain text, no color)
    if enable_file_logging:
        logs_dir = Path("logs")
        logs_dir.mkdir(parents=True, exist_ok=True)

        fp = file_path or str(logs_dir / "nsflow.log")
        file_handler = TimedRotatingFileHandler(
            filename=fp, when="midnight", interval=1, backupCount=7, encoding="utf-8"
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        root.addHandler(file_handler)

    _logging_initialized = True
    logging.getLogger(__name__).info("Logging initialized")


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


# ---------- STREAM PARSING / EMISSION ----------

def _infer_level_from_message_type(record: Dict[str, Any]) -> int:
    mt = str(record.get("message_type", "")).strip().lower()
    return MESSAGE_TYPE_TO_LEVEL.get(mt, logging.INFO)


def _infer_level_from_text(text: str, default: int = logging.INFO) -> int:
    m = _LEVEL_WORD.search(text or "")
    if not m:
        # Heuristic fallbacks for common words
        if "traceback" in (text or "").lower():
            return logging.ERROR
        return default
    word = m.group(1).upper()
    if word == "FATAL":
        return logging.CRITICAL
    return getattr(logging, word, default)


def _pretty(obj: Any) -> str:
    try:
        return json.dumps(obj, indent=2, ensure_ascii=False)
    except Exception:
        return str(obj)


def _try_parse_json_fragment(text: str) -> Optional[Dict[str, Any]]:
    """
    Attempt to parse a full JSON object from a string which may contain
    additional leading/trailing noise. Returns dict if successful.
    """
    if not text:
        return None

    # Fast path: exact JSON
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
        # If it's not an object, still return wrapped
        return {"message": obj}
    except Exception:
        pass

    # Attempt to parse first {...} block
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        snippet = text[start : end + 1]
        try:
            obj = json.loads(snippet)
            if isinstance(obj, dict):
                return obj
            return {"message": obj}
        except Exception:
            return None
    return None


# --- Special handling: NeuroSan "Request reporting: { ... }" multi-line blocks ---

# Matches:  ... "message": "Request reporting: { <inner JSON...> }",  (spans lines)
_REQUEST_REPORTING_INNER = re.compile(
    r'Request reporting:\s*\{(?P<inner>.*?)\}\s*",', re.IGNORECASE | re.DOTALL
)

# Simple extractors for trailing metadata present at the end line(s)
_META_FIELDS = ["user_id", "Timestamp", "source", "message_type", "request_id"]
_META_REGEXES = {f: re.compile(rf'"{f}"\s*:\s*"(?P<val>[^"]*)"', re.IGNORECASE) for f in _META_FIELDS}


def _extract_neurosan_request_reporting(text: str) -> Optional[Dict[str, Any]]:
    """
    If text holds the broken multi-line 'Request reporting: { ... }' payload,
    reconstruct a *synthetic* JSON object:

    {
      "message": { <parsed inner json> },
      "user_id": ..., "Timestamp": ..., "source": ..., "message_type": ..., "request_id": ...
    }
    """
    m = _REQUEST_REPORTING_INNER.search(text)
    if not m:
        return None

    # Parse inner
    inner_src = "{" + m.group("inner").strip() + "}"
    try:
        inner_obj = json.loads(inner_src)
    except Exception:
        # Inner should be valid JSON; if not, keep as string
        inner_obj = inner_src

    result: Dict[str, Any] = {"message": inner_obj}

    # Pull metadata from the rest of the text
    for field, rx in _META_REGEXES.items():
        mm = rx.search(text)
        if mm:
            result[field] = mm.group("val")

    # Provide a hint if Timestamp missing
    if "Timestamp" not in result:
        result["Timestamp"] = datetime.utcnow().isoformat()

    # Default source if missing
    if "source" not in result:
        result["source"] = "NeuroSan"

    # Default message_type if missing
    if "message_type" not in result:
        result["message_type"] = "Other"

    return result


def _decide_level(record: Dict[str, Any], fallback_text: Optional[str] = None) -> int:
    # Prefer explicit message_type
    if "message_type" in record:
        return _infer_level_from_message_type(record)

    # Heuristic from text (e.g., FastAPI / uvicorn lines)
    if fallback_text:
        return _infer_level_from_text(fallback_text)

    return logging.INFO


def _emit_json(logger: logging.Logger, record: Dict[str, Any]) -> None:
    level = _decide_level(record, None)
    pretty_block = _pretty(record)
    if level >= logging.ERROR and isinstance(record.get("message"), str):
        # If it's an error and looks like a traceback string, keep as-is (already escaped)
        pass

    if level >= logging.CRITICAL:
        logger.critical(pretty_block)
    elif level >= logging.ERROR:
        logger.error(pretty_block)
    elif level >= logging.WARNING:
        logger.warning(pretty_block)
    elif level >= logging.INFO:
        logger.info(pretty_block)
    else:
        logger.debug(pretty_block)


def _emit_text(logger: logging.Logger, source: str, text: str) -> None:
    level = _infer_level_from_text(text, logging.INFO)
    line = text if text.startswith(source + ":") else f"{source}: {text}"
    if level >= logging.CRITICAL:
        logger.critical(line)
    elif level >= logging.ERROR:
        logger.error(line)
    elif level >= logging.WARNING:
        logger.warning(line)
    elif level >= logging.INFO:
        logger.info(line)
    else:
        logger.debug(line)


def _strip_known_prefixes(source: str, line: str) -> str:
    # Common prefixes: "NeuroSan: ..." / "FastAPI: ..." (exact or padded)
    prefix = f"{source}:"
    if line.startswith(prefix):
        return line[len(prefix) :].lstrip()
    # Some logs use 'Neuro SAN' (with space) or different casing
    alt = f"{source.replace('  ', ' ').replace('SAN', 'San')}:"
    if line.startswith(alt):
        return line[len(alt) :].lstrip()
    return line


def _count_braces_outside_quotes(s: str) -> int:
    """
    Balance helper for generic JSON accumulation. Not bulletproof if the
    producer prints unescaped quotes inside strings, but good enough to
    decide when to attempt a parse.
    """
    depth = 0
    in_str = False
    esc = False
    for ch in s:
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
    return depth


class PipeLogStreamer:
    """
    Reads a text pipe line-by-line, detects JSON (single or multi-line),
    reconstructs NeuroSan 'Request reporting' JSON, and emits colorful logs.

    Keep this class in logging_setup.py; in run.py simply instantiate and call .stream(pipe).
    """

    def __init__(self, source_name: str, tee_file: Optional[str] = None) -> None:
        self.source_name = source_name
        self.logger = logging.getLogger(source_name)
        self.tee_file_handle: Optional[io.TextIOWrapper] = (
            open(tee_file, "a", encoding="utf-8") if tee_file else None
        )
        self.buffer: List[str] = []
        self.brace_balance: int = 0
        self.collecting: bool = False

    def close(self) -> None:
        if self.tee_file_handle:
            try:
                self.tee_file_handle.flush()
                self.tee_file_handle.close()
            except Exception:
                pass
            self.tee_file_handle = None

    def _tee(self, raw_line: str) -> None:
        if not self.tee_file_handle:
            return
        try:
            self.tee_file_handle.write(f"{self.source_name}: {raw_line}\n")
        except Exception:
            pass

    def _flush_buffer(self) -> None:
        text = "\n".join(self.buffer).strip()
        self.buffer.clear()
        self.collecting = False
        self.brace_balance = 0

        # 1) Try direct JSON parse (possibly from fragment)
        obj = _try_parse_json_fragment(text)
        if obj is not None:
            _emit_json(self.logger, obj)
            return

        # 2) Try special NeuroSan multi-line reassembly
        rebuilt = _extract_neurosan_request_reporting(text)
        if rebuilt is not None:
            _emit_json(self.logger, rebuilt)
            return

        # 3) Fallback: emit collapsed text (still colorized by heuristic)
        compact = " ".join(x.strip() for x in text.splitlines() if x.strip())
        _emit_text(self.logger, self.source_name, compact if compact else text)

    def _maybe_start_collect(self, line: str) -> bool:
        # Quick signal to start collecting for JSON blocks
        if "{" in line:
            self.collecting = True
            self.buffer = [line]
            self.brace_balance = _count_braces_outside_quotes(line)
            return True
        return False

    def _process_line(self, raw_line: str) -> None:
        self._tee(raw_line)

        line = raw_line.rstrip("\n")
        stripped = _strip_known_prefixes(self.source_name, line)

        if not self.collecting:
            # Single-line JSON?
            obj = _try_parse_json_fragment(stripped)
            if obj is not None:
                _emit_json(self.logger, obj)
                return

            # Start accumulating a JSON block if likely
            if self._maybe_start_collect(stripped):
                # Early flush if balance is already closed
                if self.brace_balance <= 0:
                    self._flush_buffer()
                return

            # Not JSON → plain text
            _emit_text(self.logger, self.source_name, stripped)
            return

        # We are collecting a multi-line JSON-ish block
        self.buffer.append(stripped)
        self.brace_balance += _count_braces_outside_quotes(stripped)

        # Heuristic end conditions:
        end_now = False
        if self.brace_balance <= 0:
            end_now = True
        else:
            # In broken prints, the end often carries request_id & final brace
            if '"request_id"' in stripped and stripped.strip().endswith("}"):
                end_now = True

        if end_now:
            self._flush_buffer()

    def stream(self, pipe) -> None:
        try:
            for raw in iter(pipe.readline, ""):
                self._process_line(raw.rstrip("\n"))
        finally:
            try:
                pipe.close()
            except Exception:
                pass
            self.close()
