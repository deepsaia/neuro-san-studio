"""
Central logging + subprocess stream formatting for NSFlow.

- Standard logging with colorized console + rotating file.
- A SubprocessStreamFormatter that:
  * Reassembles multi-line JSON into one object.
  * Pretty prints Neuro-SAN JSON logs (message, user_id, Timestamp, etc).
  * Detects and colorizes traceback text inside the JSON "message" field.
  * Formats plain / FastAPI/loguru-like lines nicely.
"""

from __future__ import annotations

import json
import logging
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Optional, Tuple, List


# ---------- ANSI Colors ----------

class Colors:
    RESET = '\033[0m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    CYAN = '\033[36m'
    RED = '\033[31m'
    BOLD_RED = '\033[1;31m'
    BLUE = '\033[34m'


# ---------- Console Formatter for our own logs ----------

class ColoredFormatter(logging.Formatter):
    LEVEL_COLORS = {
        'DEBUG': Colors.BLUE,
        'INFO': Colors.GREEN,
        'WARNING': Colors.YELLOW,
        'ERROR': Colors.RED,
        'CRITICAL': Colors.BOLD_RED,
    }

    def __init__(self, fmt=None, datefmt=None, use_colors=True):
        super().__init__(fmt, datefmt)
        self.use_colors = use_colors

    def format(self, record: logging.LogRecord) -> str:
        if not self.use_colors:
            return super().format(record)

        orig_levelname = record.levelname
        level_color = self.LEVEL_COLORS.get(record.levelname, '')
        record.levelname = f"{level_color}{record.levelname: <8}{Colors.RESET}"
        record.asctime = f"{Colors.GREEN}{self.formatTime(record, self.datefmt)}{Colors.RESET}"
        record.location = f"{Colors.CYAN}{record.name}:{record.funcName}:{record.lineno}{Colors.RESET}"
        out = super().format(record)
        record.levelname = orig_levelname
        return out


def setup_logging(
    log_level: str = "INFO",
    enable_file_logging: bool = True,
    force: bool = False
) -> None:
    """Idempotent standard logging setup with color console + rotating file."""
    root_logger = logging.getLogger()
    if getattr(setup_logging, "_initialized", False) and not force:
        return

    root_logger.setLevel(logging.DEBUG)
    root_logger.handlers.clear()

    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    ch.setFormatter(ColoredFormatter(
        fmt='%(asctime)s | %(levelname)s | %(location)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        use_colors=True
    ))
    root_logger.addHandler(ch)

    if enable_file_logging:
        log_dir = Path("logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = TimedRotatingFileHandler(str(log_dir / "nsflow.log"), when="midnight", interval=1, backupCount=7)
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(
            fmt='%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        root_logger.addHandler(fh)

    setup_logging._initialized = True
    logging.getLogger(__name__).info("Logging initialized")


# ---------- Tools for traceback normalization and coloring ----------

TB_START = "Traceback (most recent call last):"
TB_CHAIN_1 = "During handling of the above exception, another exception occurred:"
TB_CHAIN_2 = "The above exception was the direct cause of the following exception:"

def normalize_traceback_str(message: str) -> str:
    """
    Expand flattened or JSON-escaped traceback text to multi-line readable text.
    """
    # Unescape JSON-escaped control chars
    message = (message
               .replace("\\r", "\r")
               .replace("\\t", "\t")
               .replace("\\n", "\n")
               .replace('\\"', '"'))

    # Insert newlines before common markers
    replacements = [
        (TB_START, f"\n{TB_START}\n"),
        (TB_CHAIN_1, f"\n{TB_CHAIN_1}\n"),
        (TB_CHAIN_2, f"\n{TB_CHAIN_2}\n"),
        ("  File", "\n  File"),
        ('File "', '\nFile "'),
        ("ValueError:", "\nValueError:"),
        ("TypeError:", "\nTypeError:"),
        ("RuntimeError:", "\nRuntimeError:"),
        ("ImportError:", "\nImportError:"),
        ("Exception:", "\nException:"),
        ("Error:", "\nError:"),
    ]
    for old, new in replacements:
        message = message.replace(old, new)

    message = re.sub(r"\n{3,}", "\n\n", message)
    return message.strip()


def is_traceback_text(message: str) -> bool:
    s = message or ""
    return (TB_START in s) or ('File "' in s and ", line " in s)


def colorize_traceback(message: str) -> Tuple[str, str]:
    """
    Return (colored, plain) versions of a traceback text.
    """
    message = normalize_traceback_str(message)
    colored: List[str] = []
    plain: List[str] = []

    for raw in message.splitlines():
        line = raw.rstrip("\n")

        if line.strip().startswith("Traceback"):
            colored.append(f"{Colors.CYAN}{line}{Colors.RESET}")
            plain.append(line)
            continue

        if line.strip().startswith(("File ", "  File")):
            m = re.match(r'^\s*File "([^"]+)", line (\d+), in (.*)$', line.strip())
            if m:
                path, lineno, func = m.groups()
                colored.append(
                    f'  File {Colors.CYAN}{path}{Colors.RESET}, '
                    f'line {Colors.YELLOW}{lineno}{Colors.RESET}, '
                    f'in {Colors.GREEN}{func}{Colors.RESET}'
                )
            else:
                colored.append(f"{Colors.CYAN}{line}{Colors.RESET}")
            plain.append(line)
            continue

        # Exception line (ValueError:, TypeError:, etc.)
        m2 = re.match(r'^\s*(\w+(?:Error|Exception|Warning)):(.*)$', line.strip())
        if m2:
            etype, emsg = m2.groups()
            colored.append(f"{Colors.BOLD_RED}{etype}{Colors.RESET}:{emsg}")
            plain.append(line)
            continue

        colored.append(line)
        plain.append(line)

    return "\n".join(colored), "\n".join(plain)


# ---------- JSON helpers ----------

def try_json_loads(s: str) -> Optional[dict]:
    try:
        return json.loads(s)
    except Exception:
        return None


def extract_inner_json_from_message(message: str) -> Optional[dict]:
    """
    If a message contains a JSON object literal after some prefix text (e.g. "Request reporting: {...}"),
    extract and parse that inner JSON.
    """
    if not isinstance(message, str):
        return None

    text = message
    # Replace escaped newlines in strings
    text = text.replace("\\n", "\n")
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None

    inner = text[start:end+1]
    return try_json_loads(inner)


def iso_to_display(ts: str) -> str:
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ts[:19] if ts else ""


def pick_level(message_type: str, message_text: str) -> Tuple[str, str]:
    """
    Returns (LEVEL, level_color) based on message_type and content.
    """
    mt = (message_type or "").lower()
    msg = (message_text or "").lower()

    if mt == "error" or "traceback" in msg or "error:" in msg or "exception" in msg:
        return "ERROR", Colors.BOLD_RED
    if mt == "warning":
        return "WARNING", Colors.YELLOW
    return "INFO", Colors.GREEN


# ---------- JSON accumulator to rebuild multiline objects ----------

@dataclass
class JsonAccumulator:
    buffer: List[str]
    depth: int
    in_string: bool
    escape: bool
    started: bool

    def __init__(self) -> None:
        self.buffer = []
        self.depth = 0
        self.in_string = False
        self.escape = False
        self.started = False

    def reset(self) -> None:
        self.buffer.clear()
        self.depth = 0
        self.in_string = False
        self.escape = False
        self.started = False

    def feeding(self) -> bool:
        return self.started

    def _scan(self, s: str) -> None:
        """Advance depth/in_string/escape states for this line, ignoring braces inside strings."""
        i = 0
        while i < len(s):
            ch = s[i]
            if self.escape:
                self.escape = False
                i += 1
                continue
            if ch == '\\':
                if self.in_string:
                    self.escape = True
                i += 1
                continue
            if ch == '"':
                self.in_string = not self.in_string
                i += 1
                continue
            if not self.in_string:
                if ch == '{':
                    self.depth += 1
                elif ch == '}':
                    self.depth -= 1
            i += 1

    def feed(self, line: str) -> Optional[str]:
        """
        Feed one raw line. When the full JSON object is complete, return it as a single string.
        Otherwise return None (keep buffering).
        """
        s = line.rstrip("\n")
        if not self.started:
            # Only start when the first non-space char is '{'
            if s.lstrip().startswith("{"):
                self.started = True
            else:
                return None

        self.buffer.append(s)
        self._scan(s)

        if self.started and self.depth == 0:
            joined = " ".join(self.buffer)
            self.reset()
            return joined
        return None


# ---------- TracebackAccumulator to rebuild multi-line tracebacks ----------

class TracebackAccumulator:
    def __init__(self) -> None:
        self.active = False
        self.lines: List[str] = []
        self.seen_exc_line = False

    def reset(self) -> None:
        self.active = False
        self.lines.clear()
        self.seen_exc_line = False

    def start_if_needed(self, s: str) -> bool:
        if "Traceback (most recent call last):" in s:
            self.active = True
            self.lines = [s]
            self.seen_exc_line = False
            return True
        return False

    def feed(self, s: str) -> Optional[str]:
        """
        Return the full traceback text when complete, else None.
        Heuristic end: blank line *after* we've seen an exception line (ValueError:, TypeError:, etc.)
        """
        if not self.active:
            return None
        self.lines.append(s)
        if re.match(r'^\s*\w+(?:Error|Exception|Warning):', s.strip()):
            self.seen_exc_line = True
        if self.seen_exc_line and s.strip() == "":
            text = "\n".join(self.lines)
            self.reset()
            return text
        return None


# ---------- Stream formatter for subprocess output ----------

class SubprocessStreamFormatter:
    LOGURU_RE = re.compile(
        r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \| (\w+)\s+\| ([^-]+) - (.*)$'
    )

    def __init__(self, source_label: str) -> None:
        self.source_label = source_label  # e.g., "Neuro SAN" / "FastAPI"
        self.json_acc = JsonAccumulator()
        self.tb_acc = TracebackAccumulator()  # NEW

    def feed(self, line: str) -> Optional[Tuple[str, str]]:
        if not line:
            return None

        stripped = line.rstrip("\n")

        # 1) If we are assembling a JSON object, continue until balanced.
        if self.json_acc.feeding():
            complete_json = self.json_acc.feed(stripped)
            if complete_json is not None:
                return self._format_neurosan_json_block(complete_json)
            return None

        # 2) Start JSON capture if this line begins an object.
        if stripped.lstrip().startswith("{"):
            self.json_acc.feed(stripped)
            return None  # wait for completion

        # 3) Collect a plain-text traceback block (non-JSON) as one unit
        if self.tb_acc.active:
            done = self.tb_acc.feed(stripped)
            if done is not None:
                return self._format_traceback_block(done)
            return None

        if self.tb_acc.start_if_needed(stripped):
            return None

        # 4) Try FastAPI/uvicorn/loguru-like line
        m = self.LOGURU_RE.match(stripped)
        if m:
            ts, level, module_info, message = m.groups()
            return self._format_fastapi_like(ts, level, module_info, message)

        # 5) Plain passthrough
        return self._format_plain(stripped)

    def _format_traceback_block(self, tb_text: str) -> Tuple[str, str]:
        colored_tb, plain_tb = colorize_traceback(tb_text)
        colored = f"{self.source_label}: {Colors.BOLD_RED}ERROR{Colors.RESET} -\n{colored_tb}\n"
        plain = f"{self.source_label}: ERROR -\n{plain_tb}\n"
        return colored, plain

    # ---- formatting helpers ----

    def _format_plain(self, text: str) -> Tuple[str, str]:
        colored = f"{self.source_label}: {text}\n"
        plain = f"{self.source_label}: {text}\n"
        return colored, plain

    def _format_fastapi_like(self, ts: str, level: str, module_info: str, message: str) -> Tuple[str, str]:
        level_color = {
            "ERROR": Colors.BOLD_RED,
            "CRITICAL": Colors.BOLD_RED,
            "WARNING": Colors.YELLOW,
            "DEBUG": Colors.BLUE,
        }.get(level.upper(), Colors.GREEN)

        # If message itself is JSON, pretty print it
        pretty_message = message
        maybe = try_json_loads(message.strip())
        if maybe is not None:
            pretty_message = "\n" + json.dumps(maybe, indent=2, ensure_ascii=False)

        colored = (
            f"{self.source_label}: "
            f"{Colors.GREEN}{ts}{Colors.RESET} | "
            f"{level_color}{level: <8}{Colors.RESET} | "
            f"{Colors.CYAN}{module_info.strip()}{Colors.RESET} - {pretty_message}\n"
        )
        plain = f"{self.source_label}: {ts} | {level: <8} | {module_info.strip()} - {pretty_message}\n"
        return colored, plain

    def _format_neurosan_json_block(self, json_string: str) -> Tuple[str, str]:
        """
        Pretty print Neuro-SAN JSON events with colored header and message handling.
        """
        data = try_json_loads(json_string)
        if data is None:
            # not valid JSON after all; show raw
            return self._format_plain(json_string)

        # Neuro-SAN canonical fields
        message = data.get("message", "")
        ts = iso_to_display(data.get("Timestamp", ""))
        level, level_color = pick_level(data.get("message_type", ""), str(message))
        source = data.get("source", self.source_label)

        # Message formatting:
        colored_msg: str
        plain_msg: str

        if isinstance(message, (dict, list)):
            # Already structured JSON
            pretty = json.dumps(message, indent=2, ensure_ascii=False)
            colored_msg = "\n" + pretty
            plain_msg = "\n" + pretty
        elif isinstance(message, str) and is_traceback_text(message):
            colored_msg, plain_msg = colorize_traceback(message)
            colored_msg = "\n" + colored_msg
            plain_msg = "\n" + plain_msg
        elif isinstance(message, str):
            # Try to extract inner JSON from the string (e.g., "Request reporting: { ... }")
            inner = extract_inner_json_from_message(message)
            if inner is not None:
                prefix = message[:message.find("{")].strip()
                pretty_inner = json.dumps(inner, indent=2, ensure_ascii=False)
                if prefix:
                    colored_msg = "\n" + f"{prefix}\n" + pretty_inner
                    plain_msg = "\n" + f"{prefix}\n" + pretty_inner
                else:
                    colored_msg = "\n" + pretty_inner
                    plain_msg = "\n" + pretty_inner
            else:
                colored_msg = "\n" + message.strip()
                plain_msg = "\n" + message.strip()
        else:
            colored_msg = "\n" + str(message)
            plain_msg = "\n" + str(message)

        # Build “pretty printed JSON-like” output with the message rendered multi-line.
        # (Colored version embeds ANSI into the "message" display; file/plain is clean.)
        colored_body = self._render_json_with_message(data, colored_msg, use_color=True)
        plain_body = self._render_json_with_message(data, plain_msg, use_color=False)

        colored_line = (
            f"{self.source_label}: "
            f"{Colors.GREEN}{ts}{Colors.RESET} | {level_color}{level: <8}{Colors.RESET} | "
            f"{Colors.CYAN}{source}{Colors.RESET} -\n{colored_body}\n"
        )
        plain_line = f"{self.source_label}: {ts} | {level: <8} | {source} -\n{plain_body}\n"
        return colored_line, plain_line

    @staticmethod
    def _render_json_with_message(data: dict, rendered_message: str, use_color: bool) -> str:
        """
        Render a JSON object as pretty text while inserting an already-formatted, multi-line "message" value.
        We keep keys as JSON-ish, but the "message" value is injected as-is for readability.
        """
        lines: List[str] = ["{"]
        items = list(data.items())
        for i, (k, v) in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            if k == "message":
                # Insert the pre-rendered multi-line message value
                # Indent each line by two spaces to look like JSON field content
                indented = "\n".join("  " + ln for ln in rendered_message.splitlines())
                lines.append(f'  "{k}":')
                lines.append(indented + comma)
            else:
                lines.append(f'  "{k}": {json.dumps(v, ensure_ascii=False)}{comma}')
        lines.append("}")
        return "\n".join(lines)


# convenience for external modules
def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
