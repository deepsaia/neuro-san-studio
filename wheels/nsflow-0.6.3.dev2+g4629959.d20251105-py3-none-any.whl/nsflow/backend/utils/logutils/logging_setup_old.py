"""
Logging configuration setup using standard Python logging library.

This module provides a centralized logging configuration with color-coded output,
file rotation, and proper formatting.
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from logging.handlers import TimedRotatingFileHandler


# ANSI color codes
class Colors:
    RESET = '\033[0m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    CYAN = '\033[36m'
    RED = '\033[31m'
    BOLD_RED = '\033[1;31m'
    BLUE = '\033[34m'


# Track initialization state to make function idempotent
_logging_initialized = False


class ColoredFormatter(logging.Formatter):
    """Custom formatter with color support."""

    LEVEL_COLORS = {
        'DEBUG': Colors.BLUE,
        'INFO': Colors.GREEN,
        'WARNING': Colors.YELLOW,
        'ERROR': Colors.RED,
        'CRITICAL': Colors.BOLD_RED,
    }

    def __init__(self, fmt=None, datefmt=None, use_colors=True):
        super().__init__(fmt, datefmt)
        self.use_colors = use_colors

    def format(self, record):
        if self.use_colors:
            # Save original levelname
            orig_levelname = record.levelname

            # Add colors
            level_color = self.LEVEL_COLORS.get(record.levelname, '')
            record.levelname = f"{level_color}{record.levelname: <8}{Colors.RESET}"

            # Format time in green
            record.asctime = f"{Colors.GREEN}{self.formatTime(record, self.datefmt)}{Colors.RESET}"

            # Format location in cyan
            record.location = f"{Colors.CYAN}{record.name}:{record.funcName}:{record.lineno}{Colors.RESET}"

            # Format the message
            formatted = super().format(record)

            # Restore original
            record.levelname = orig_levelname

            return formatted
        else:
            return super().format(record)


def setup_logging(
    log_level: str = "INFO",
    enable_file_logging: bool = True,
    force: bool = False
):
    """
    Setup standard logging with colors.

    This function is idempotent - calling it multiple times will not
    re-initialize logging unless force=True.

    Args:
        log_level: Minimum log level (default: INFO)
        enable_file_logging: Whether to enable file logging (default: True)
        force: Force re-initialization even if already initialized (default: False)
    """
    global _logging_initialized

    # Skip if already initialized (unless forced)
    if _logging_initialized and not force:
        return

    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    # Remove existing handlers
    root_logger.handlers.clear()

    # Console handler with colors
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(getattr(logging, log_level.upper()))

    console_formatter = ColoredFormatter(
        fmt='%(asctime)s | %(levelname)s | %(location)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        use_colors=True
    )
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    # File handler (if enabled)
    if enable_file_logging:
        log_dir = Path("logs")
        log_dir.mkdir(parents=True, exist_ok=True)

        file_handler = TimedRotatingFileHandler(
            filename=log_dir / "nsflow.log",
            when='midnight',
            interval=1,
            backupCount=7
        )
        file_handler.setLevel(logging.DEBUG)

        file_formatter = logging.Formatter(
            fmt='%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)

    # Mark as initialized
    _logging_initialized = True

    logging.info("Logging initialized")


def get_logger(name: str):
    """
    Get a logger instance with the given name.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance
    """
    return logging.getLogger(name)
